<x-layout>
    <x-slot name='title'>Home</x-slot>
    <x-slot name='content'> Main Content
        <div class="mt-5">
            <div class="text-center">
                <img src="{{asset('images/kamal2.jpg')}}" alt="" class="img-thumbnail" width="250px" height="150px">
            </div>
            <div class="mt-5 text-white mx=5 text-justify">
                <h1 class="fw-bold st-font">Hello,</h1>
                <div class="px-4" style="line-height: 2rem;">
                <p style="text-indent:100px"> I am <b class="text-warning"> Ashish Kumar Singh  </b> having 1 year of full-stack web development experience
            and  good problem solving skils </p>

                </div>

            </div>

            <div class="text-center">
                <a href="{{route('contact')}}" class="btn btn-outline-warning mx-5 my-3">Hire Me</a>
                <a href="{{route('contact')}}" class="btn btn-outline-info">Contact</a>
            </div>

        </div>
        <i class="fas fa-map-market-alt fa-2x i-color"></i>
    </x-slot>
</x-layout>