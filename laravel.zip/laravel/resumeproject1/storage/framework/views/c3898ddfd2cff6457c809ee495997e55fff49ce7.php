<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Service <?php $__env->endSlot(); ?>
     <?php $__env->slot('content', null, []); ?> 
        <div class="container mt-5">
            <h1 class="text-warning mb-5 border-bottom">SERVICES</h1>
            
            <div class="row text-center text-white mb-5">
                <div class="col-sm-4">
                    <i class="fas fa-search-dollar fa-2x mb-3 i-color"></i>
                    <h3>SEO</h3>
                <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid unde magni error quo, mollitia accusantium veniam optio, velit rem libero modi dolore eligendi amet harum, nesciunt excepturi obcaecati vitae ea.
                Perferendis eos modi id eveniet, maiores dolorum neque! Dignissimos ipsam ex laudantium magni dicta fuga ullam dolore quaerat exercitationem nihil officia nobis provident eaque temporibus molestiae ducimus, libero modi praesentium.</p>
</div>
<div class="col-sm-4">
    <i class="fas fa-palette fa-2x mb-3 i-color"></i>
    <h2>Web Design</h3>
    <p class="ss-color">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Fugit quibusdam blanditiis eveniet illo, placeat laudantium quam corporis, porro totam labore dicta rem! Harum repellat ullam et. Reiciendis architecto impedit corporis.
    Architecto in voluptatum rerum at fugit non illo earum voluptates repellerepellendus  dog animi fugiat quis ex magnam iusto ducimus ipsa aperiam! Consequatur dolor magni temporibus alias!</p>
</div>
<div class="col-sm-4">
    <i class=fas fa-code fa-2x mb-3 i-color"></i>
    <h3> Web development</h3>
    <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur in, aliquam iure totam ipsum labore sunt sint consequuntur assumenda asperiores harum hic nostrum error aperiam ut sed facere officia soluta.
    Ut velit facilis distinctio reiciendis perspiciatis sunt natus re ipsum aliquid illo velit repellat esse, similique ea quam! Qui quas quae adipisci, nam architecto voluptas perspiciatis eius aliquam?</p>
</div>
</div>
<div class="row text-center text-white mb-5">
    <div class="col-m-4">
        <i class="fab fa-android fa-2x mb-3 i-color"></i>
        <h3>Android</h3>
        <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum sit pariatur neque amet ullam, dolores eligendi vitae perspiciatis voluptas explicabo recusandae numquam odio consequuntur nobis aperiam eaque reiciendis autem dignissimos.
        Error maiores eveniet beatae doloribus animi quasi illum delectus! Doloribus odio similique fugit, error ea asperiores? Magni, cum aspernatur ducimus numquam quod libero tempora ratione nam soluta incidunt eos quisquam.</p>
</div>
<div class="col-sm-4">
    <i class="fab fa-apple fa-2x mb-3 i-color"></i>
    <h3>IOS</h3>
    <p class="ss-color">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Recusandae facere nam natus? Harum itaque voluptatibus possimus sequi suscipit, tempore mollitia iusto! Aut nulla repudiandae voluptate optio ipsam placeat a quos!
</p>
</div>
<div class="col-sm-4">
    <i class="fas fa-ad fa-2x mb-3 i-color"></i>
    <h3>Advertising</h3>
    <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam, quis? Dignissimos laudantium dolorum ullam illum odit! Voluptatem beatae molestiae officia, doloremque soluta velit, accusamus nesciunt sint ducimus culpa dolorum? Hic.
</p>
</div>
</div>
<div class="row text-center text-white mb-5">
    <div class="col-sm-4">
        <i class="fas fa-pencil-alt fa-2x mb-3 i-color"></i>
        <h3>Logo Design</h3>
        <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae enim, nesciunt temporibus, dolores harum commodi magni, reprehenderit molestias excepturi cupiditate minus. Laboriosam illo placeat maxime! Porro magnam aut id assumenda.
</p>
</div>
<div class="col-sm-4">
    <i class="fas fa-database fa-2x mb-3 i-color"></i>
    <h3>Hosting</h3>
    <p class="ss-color">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Illum amet dolor quaerat aspernatur alias provident eligendi non inventore maiores asperiores cumque quasi quia, ratione culpa doloremque dicta tempore et magni.
</p>
</div>
<div class="col-sm-4">
    <i class="fas fa-headset fa-2x mb-3 i-color"></i>
    <h3>Support</h3>
    <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo asperiores aperiam voluptates dolores soluta? Tempore adipisci iusto a animi, eius molestiae illum in. Deserunt rerum vel non nostrum nesciunt! Corrupti.
</p>

</div>
</div>
</div>
 <?php $__env->endSlot(); ?> 
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?>
<?php /**PATH C:\laravel\resumeproject1\resources\views/services.blade.php ENDPATH**/ ?>